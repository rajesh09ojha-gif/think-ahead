from flask import Flask, render_template, request
import random

app = Flask(__name__)

def compute_bmi(weight_kg, height_cm):
    try:
        h = float(height_cm) / 100.0
        if h <= 0: return 0.0
        return float(weight_kg) / (h*h)
    except Exception:
        return 0.0

def clamp(n, lo, hi):
    return max(lo, min(hi, n))

def generate_advice(name, age, cls, weight, height, marks, study_hours, junk_intake, sleep_hours):
    bmi = compute_bmi(weight, height)
    lines = []

    # Pools
    if bmi == 0:
        bmi_msg = ["BMI couldn't be computed—please check height/weight.", "BMI invalid—verify your entries and try again."]
    elif bmi < 18.5:
        bmi_msg = ["BMI is below healthy range—add protein-rich foods and regular meals.", "Slightly under BMI—nutritious snacks (nuts, milk, eggs) help."]
    elif bmi <= 24.9:
        bmi_msg = ["BMI in healthy range—maintain balanced meals and light daily activity.", "Healthy BMI—keep routine steady with home-cooked meals."]
    else:
        bmi_msg = ["BMI above range—daily walks and portion control will help.", "High BMI—swap sugary drinks for water and add 20–30 min movement."]

    if sleep_hours < 7:
        sleep_msg = ["Boost sleep to 7–8 hours; avoid screens an hour before bed.", "Short sleep hurts memory—aim for fixed bedtime and darker room."]
    elif sleep_hours > 9:
        sleep_msg = ["Long sleep is fine—add daylight exposure and short active breaks.", "Great rest—keep wake-up time consistent to stay energized."]
    else:
        sleep_msg = ["Sleep looks solid—pair study with 5‑minute breaks.", "Good rhythm—protect it during exam weeks with earlier wind-downs."]

    if study_hours < 2:
        study_msg = ["Start with one focused 40‑minute block using Pomodoro + recall.", "Begin 30–45 minutes daily; grow to 2–3 hours with spaced repetition."]
    elif study_hours < 4:
        study_msg = ["Good study time—add past papers and weekly review sheets.", "Consistent effort—include timed sets and an error log."]
    else:
        study_msg = ["Great consistency—rotate topics and schedule real breaks.", "Strong grind—target weak spots first each session."]

    if marks < 50:
        marks_msg = ["Master 2 weak topics this week to raise your baseline.", "Build fundamentals—short notes + daily practice will lift scores."]
    elif marks < 75:
        marks_msg = ["Close to excellence—mix practice sets and teach a friend.", "Push up with timed mocks and concept maps."]
    else:
        marks_msg = ["Great trajectory—weekly mocks + error‑log review keep you sharp.", "Maintain momentum—tackle advanced problems and explain aloud."]

    if junk_intake >= 4:
        junk_msg = ["Cut junk to once a week; swap in fruit or nuts.", "Reduce fried snacks; hydration + balanced meals stabilize energy."]
    elif junk_intake >= 2:
        junk_msg = ["Keep treats moderate; pair with veggies and protein.", "Trim junk slightly and add water goals—small changes add up."]
    else:
        junk_msg = ["Great moderation—prioritize whole foods.", "Food choices look disciplined—keep portions balanced."]

    lines.extend([
        random.choice(bmi_msg),
        random.choice(sleep_msg),
        random.choice(study_msg),
        random.choice(marks_msg),
        random.choice(junk_msg),
        f"{name}, focus on steady routines—small daily wins compound fast."
    ])

    # Performance score
    bmi_penalty = 10 if bmi and (bmi < 18.5 or bmi > 24.9) else 0
    sleep_score = clamp((sleep_hours/8)*100, 0, 120)
    study_score = clamp((study_hours/4)*100, 0, 150)
    marks_score = clamp(marks, 0, 100)
    junk_penalty = clamp(junk_intake*8, 0, 40)
    perf = clamp((sleep_score*0.25 + study_score*0.25 + marks_score*0.5) - junk_penalty - bmi_penalty, 0, 100)

    recommended = {"sleep": 7.5, "study": 3.0 if marks < 75 else 2.5, "junk": 1.0}

    return {
        "bmi": round(bmi, 2),
        "performance": round(perf, 1),
        "advice_lines": lines,
        "recommended": recommended
    }

@app.route("/")
def welcome():
    return render_template("welcome.html")

@app.route("/start")
def start():
    return render_template("main.html")

@app.route("/predict", methods=["POST"])
def predict():
    f = request.form
    name = (f.get("name") or "Student").strip()
    age = int(float(f.get("age") or 0))
    cls = (f.get("cls") or "").strip()
    weight = float(f.get("weight") or 0)
    height = float(f.get("height") or 0)
    marks = float(f.get("marks") or 0)
    study_hours = float(f.get("study_hours") or 0)
    junk_intake = float(f.get("junk_intake") or 0)
    sleep_hours = float(f.get("sleep_hours") or 0)

    result = generate_advice(name, age, cls, weight, height, marks, study_hours, junk_intake, sleep_hours)

    study_vs_marks = {"labels": ["Study Hours", "Marks"], "data": [study_hours, marks]}
    sleep_vs_marks = {"labels": ["Sleep Hours", "Marks"], "data": [sleep_hours, marks]}
    combined = {"labels": ["Study Hours", "Sleep Hours"], "marks": [study_hours, sleep_hours], "marks_value": marks}
    current_vs_reco = {"labels": ["Sleep (hrs)", "Study (hrs)", "Junk (/wk)"], "current": [sleep_hours, study_hours, junk_intake], "recommended": [result["recommended"]["sleep"], result["recommended"]["study"], result["recommended"]["junk"]]}
    bmi_compare = {"labels": ["Your BMI", "Ideal Min", "Ideal Max"], "data": [result["bmi"], 18.5, 24.9]}

    return render_template("result.html",
                           name=name, age=age, cls=cls,
                           weight=weight, height=height,
                           marks=marks, study_hours=study_hours, junk_intake=junk_intake, sleep_hours=sleep_hours,
                           performance=result["performance"], bmi=result["bmi"], advice_lines=result["advice_lines"],
                           study_vs_marks=study_vs_marks, sleep_vs_marks=sleep_vs_marks, combined=combined,
                           current_vs_reco=current_vs_reco, bmi_compare=bmi_compare)

if __name__ == "__main__":
    app.run(debug=True)
