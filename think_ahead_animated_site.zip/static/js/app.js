// Load Chart.js from CDN if local is placeholder
if (typeof Chart === "undefined" || !Chart.defaults) {
  const s = document.createElement('script');
  s.src = "https://cdn.jsdelivr.net/npm/chart.js";
  document.head.appendChild(s);
}

window.renderCharts = function(studyMarks, sleepMarks, combined, currentReco, bmiCmp){
  function go(){
    function mk(id, cfg){
      const el = document.getElementById(id);
      if(!el) return;
      new Chart(el.getContext('2d'), cfg);
    }
    mk('studyMarks', {
      type:'line',
      data:{ labels: studyMarks.labels, datasets:[{label:'Study vs Marks', data: studyMarks.data, fill:false, tension:.3}] },
      options:{ responsive:true, animation:{duration:1800, easing:'easeInOutQuart'}, scales:{y:{beginAtZero:true}} }
    });
    mk('sleepMarks', {
      type:'bar',
      data:{ labels: sleepMarks.labels, datasets:[{label:'Sleep vs Marks', data: sleepMarks.data}] },
      options:{ responsive:true, animation:{duration:1600}, scales:{y:{beginAtZero:true}} }
    });
    mk('combined', {
      type:'bar',
      data:{
        labels: combined.labels,
        datasets:[
          {type:'bar', label:'Hours', data: combined.marks},
          {type:'line', label:'Marks', data:[combined.marks_value, combined.marks_value], fill:false, tension:.2}
        ]
      },
      options:{ responsive:true, animation:{duration:1600}, scales:{y:{beginAtZero:true}} }
    });
    mk('currentReco', {
      type:'radar',
      data:{ labels: currentReco.labels, datasets:[{label:'Current', data: currentReco.current},{label:'Recommended', data: currentReco.recommended}] },
      options:{ responsive:true, animation:{duration:1600}, elements:{line:{tension:.25}} }
    });
    mk('bmiCompare', {
      type:'bar',
      data:{ labels: bmiCmp.labels, datasets:[{label:'BMI', data: bmiCmp.data}] },
      options:{ responsive:true, animation:{duration:1600}, scales:{y:{beginAtZero:true}} }
    });
  }
  if (typeof Chart === "undefined" || !Chart.defaults) {
    setTimeout(go, 600);
  } else {
    go();
  }
};
